import javafx.animation.PauseTransition;
import javafx.util.Duration;

import java.io.IOException;
import java.io.Serializable;

public class PokerInfo implements Serializable {
    Player player;
    Dealer theDealer;
    boolean playerDecides;
    boolean playerFolds;
    String text;


    private void checkWinning(){
        if (playerDecides) {
//            showDealerCards("show");//Show player's Card
            if(playerFolds) {
//                gameInfoLabel.setText("Both players loses wager");
            }
            else if (ThreeCardLogic.dealerQualifies(theDealer.getDealersHand())) {
//                setGameInfoLabelDelay("Checking Winnings", 1);
                //Comparing each player hand
                int presult = ThreeCardLogic.compareHands(theDealer.getDealersHand(), player.getHand());

                //Player1 wins and doesn't fold
                if (presult == 2 && !playerFolds) {
                    player.setTotalWinnings(player.getAnteBet() * 2);
                    player.setTotalWinnings(player.getPlayBet() * 2);

                    if (player.getPairPlusBet() != 0) {//Checks for pair plus winning
                        int newPP = ThreeCardLogic.evalPPWinnings(player.getHand(), player.getPairPlusBet());
                        player.setTotalWinnings(newPP);
                        text = "Player1 Wins AntePair $" + (player.getAnteBet() * 2) + " and PairPlus: $" + newPP;
//                        setGameInfoLabelDelay(text, 2.5);

                    } else {
                        text = "Player1 Wins: $" + player.getTotalWinnings();
//                        setGameInfoLabelDelay(text, 2.5);
                    }
                } else if (presult == 1 && !playerFolds) {//Dealer Wins against Player1
                    text = "Dealer Wins against Player1";
//                    setGameInfoLabelDelay(text, 2.5);
                    player.resetBets();
                } else if (presult == 0 && !playerFolds){//Dealer Ties with Player
                    text = "Dealer ties Player1";
//                    setGameInfoLabelDelay(text, 2.5);
                }
            else{//Dealer does not qualify
                text = "Dealer does not have at least Queen high; ante wager is pushed";
//                setGameInfoLabelDelay(text, 1);
                PauseTransition pause = new PauseTransition(Duration.seconds(4));//4 sec delay
                pause.setOnFinished(event -> {
//                    continueGame();
                });
                pause.play();
                return;
            }
//            setGameInfoLabelDelay("Game End!", 8);
//            setGameInfoLabelDelay("Click 'Fresh Start' in the menu to begin a new game", 9);

            PauseTransition pause = new PauseTransition(Duration.seconds(10));//10 sec delay
            pause.setOnFinished(event -> {
//                try {
////                    endGameScreen();
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
//            });
            pause.play();}

//        }
//    }



//}
